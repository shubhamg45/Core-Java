class BasicArrays{
    public static void main(String[] args) {
        int [] a;
        int b [];
        int [][] c;
        int [] d[];
        int [][] e;
        int []f,g;
        int h[],i;
        int []j[],k;
        int [][]l[],m,n;
        int [][]p,[]r,s;
        int [][]aa,bb[],cc;

    }
}