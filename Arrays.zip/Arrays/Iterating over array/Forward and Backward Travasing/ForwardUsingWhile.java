class ForwardUsingWhile{
	public static void main(String[] args) {
		
		int [] arr={10,20,30,40,50};

		int i=0;
		while(i<arr.length){
			System.out.println(arr[i++]+" ");
		}

	}
}