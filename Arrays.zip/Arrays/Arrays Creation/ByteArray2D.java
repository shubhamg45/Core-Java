import java.util.Arrays;
class ByteArray2D{
	public static void main(String[] args) {
	
	byte [][] a=new byte [2][3];

    a[0][0]=1;
    a[0][1]=2;
    a[0][2]=3;
    a[1][0]=4;
    a[1][1]=5;
    a[1][2]=6;
    System.out.println(Arrays.deepToString(a));

	}
}